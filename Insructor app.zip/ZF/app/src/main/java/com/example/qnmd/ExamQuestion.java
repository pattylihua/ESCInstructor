package com.example.qnmd;

/**
 * Created by derek on 4/2/2018.
 */

public class ExamQuestion {


    public String Question="";
    public String point="";
    public String A="";
    public String B="";
    public String C="";
    public String D="";
    public String answer="";
    public int type=0;
}
